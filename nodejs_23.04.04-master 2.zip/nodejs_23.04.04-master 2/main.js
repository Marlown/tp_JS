 function A(){
    $. ajax({
      type:'GET',
      URL: '/api/articles',
      success: function(data){
        console.log('sucess', data);
      }
  
    });
  
  
  }
  A();
  