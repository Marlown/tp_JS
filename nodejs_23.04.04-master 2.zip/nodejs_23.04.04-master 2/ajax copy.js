function loadDoc() {
    const xhttp = new XMLHttpRequest();// jquery pour mettre les paramètre en cas dde succès ; créé des articles à afficher faire une boucle sur les éléments 
    xhttp.onload = function() {
      //document.getElementById("demo").innerHTML = this.responseText;
      }//
    xhttp.open("GET", "http://localhost:3000/posts", true);
    xhttp.send();
  }

loadDoc();

