$(document).ready(function() {
    $('form').submit(function(event) {
        event.preventDefault(); // Empêche la soumission du formulaire
        var titre = $('#titre').val();
        var contenu = $('#contenu').val();
        var data = { titre: titre, contenu: contenu };
        $.ajax({
            url: 'https://localhost:3000/api/articles',
            type: 'post',
            contentType: 'application/json',
            data: JSON.stringify(data),
            success: function(data) {
                $('#message').html("L'article a été ajouté avec succès.");
                $('#message').slideDown();
            },
            error: function() {
                $('#message').html("Une erreur s'est produite.");
                $('#message').slideDown();
            }
        });
    });
});